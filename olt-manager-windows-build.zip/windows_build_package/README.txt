===========================================
  OLT Manager - Windows Build Package
===========================================

STEPS TO BUILD:

1. Install Python 3.10 or 3.11 from:
   https://www.python.org/downloads/
   
   IMPORTANT: Check "Add Python to PATH" during install!

2. Open Command Prompt in this folder

3. Install dependencies:
   pip install -r requirements.txt

4. Run the build:
   build_windows.bat

5. Wait 30-60 minutes for compilation

6. Your .exe will be at:
   dist\olt-manager.exe

===========================================
