#!/bin/bash
cd "$(dirname "$0")"
./olt-manager
